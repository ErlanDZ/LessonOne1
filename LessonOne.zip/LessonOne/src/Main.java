public class Main {

    public static void main(String[] args) {

        int x = 20;

        final String STR = " HELLO ";



        x =  x + 10;

        System.out.println(x + );

        if (x ){
            System.out.println("x == 20");
        }


        if (x < 40) {
            System.out.println("x < 40");
        }

        if (x > 0) {
            System.out.println("x > 0");
        }



//        {
//            System.out.println("NULL");
//        }

    }
}